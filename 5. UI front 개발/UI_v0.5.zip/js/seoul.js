//서블릿에서 데이터를 JSON 형태로 받아옴
//서버는 아직 미구현이기에 임시로 JSON 형식 데이터 할당
//데이터는 지역 -> 연도 -> 4대 질병(고지혈증, 치매, 당뇨, 고혈압) 순으로 저장
var newChart;
var region;
var labelData = []; //라벨 데이터

var selectYearStart = document.getElementById("year-select-start");
var selectYearEnd = document.getElementById("year-select-end");
var selectYearStartValue
var selectYearEndValue

//강남 고지혈증, 치매, 당뇨병, 고혈압 임시 변수
var seoulInputHyper;
var seoulInputDementia;
var seoulInputDiabetes;
var seoulInputHbp;



//고지혈증, 치매, 당뇨, 고혈압 순 데이터
var seoulHyper = [];
var seoulDementia = [];
var seoulDiabetes = [];
var seoulHbp = [];


//각 질병 버튼 상태
var hyperBtnStatus = "on";
var demenBtnStatus = "off";
var diaBtnStatus = "off";
var hbpBtnStatus = "off";

/*DB와 연결되면 유동적으로 데이터를 바꿀 수 있게 설정*/
var seoulData = { //서울 데이터
    2013: {
        'hyperlipidemia': 40,   // 고지혈증
        'dementia': 15,        // 치매
        'diabetes': 30,        // 당뇨
        'hbp': 45              // 고혈압
    },
    2014: {
        'hyperlipidemia': 42,
        'dementia': 16,
        'diabetes': 32,
        'hbp': 47
    },
    2015: {
        'hyperlipidemia': 38,
        'dementia': 14,
        'diabetes': 28,
        'hbp': 43
    },
    2016: {
        'hyperlipidemia': 41,
        'dementia': 17,
        'diabetes': 31,
        'hbp': 46
    },
    2017: {
        'hyperlipidemia': 39,
        'dementia': 18,
        'diabetes': 29,
        'hbp': 44
    },
    2018: {
        'hyperlipidemia': 43,
        'dementia': 20,
        'diabetes': 34,
        'hbp': 50
    },
    2019: {
        'hyperlipidemia': 37,
        'dementia': 13,
        'diabetes': 27,
        'hbp': 42
    },
    2020: {
        'hyperlipidemia': 44,
        'dementia': 19,
        'diabetes': 35,
        'hbp': 51
    },
    2021: {
        'hyperlipidemia': 36,
        'dementia': 12,
        'diabetes': 26,
        'hbp': 41
    },
    2022: {
        'hyperlipidemia': 45,
        'dementia': 21,
        'diabetes': 36,
        'hbp': 52
    },
    2023: {
        'hyperlipidemia': 45,
        'dementia': 21,
        'diabetes': 36,
        'hbp': 52
    }
};



function initData() {
    labelData = []; //라벨 데이터 초기화
    //데이터 초기화
    seoulHyper = [];
    seoulDementia = [];
    seoulDiabetes = [];
    seoulHbp = [];

    selectYearStartValue = selectYearStart.options[selectYearStart.selectedIndex].value;
    selectYearEndValue = selectYearEnd.options[selectYearEnd.selectedIndex].value;

    for (let i = selectYearStartValue; i <= selectYearEndValue; i++) {
        labelData.push(i);
        seoulHyper.push(seoulData[i]["hyperlipidemia"]);
        seoulDementia.push(seoulData[i]["dementia"]);
        seoulDiabetes.push(seoulData[i]["diabetes"]);
        seoulHbp.push(seoulData[i]["hbp"]);
    }
}

//질병 데이터 체크 함수
function checkBtn() {
    //고지혈증 버튼
    if (hyperBtnStatus === "on") {
        seoulInputHyper = seoulHyper;
    }

    else if (hyperBtnStatus === "off") {
        seoulInputHyper = [];
    }

    //치매 버튼
    if (demenBtnStatus === "on") {
        seoulInputDementia = seoulDementia;
    }

    else if (demenBtnStatus === "off") {
        seoulInputDementia = [];
    }

    //당뇨병 버튼
    if (diaBtnStatus === "on") {
        seoulInputDiabetes = seoulDiabetes;
    }

    else if (diaBtnStatus === "off") {
        seoulInputDiabetes = [];
    }

    //고혈압 버튼
    if (hbpBtnStatus === "on") {
        seoulInputHbp = seoulHbp;
    }

    else if (hbpBtnStatus === "off") {
        seoulInputHbp = [];
    }
}



//셀렉트 차트 적용(데이터)
document.getElementById('seoul-select').addEventListener('change', function () {
    chartSet();
});


//지역 체크
function checkRegion(value) {
    if (value === "gangnam") {
        //seoulData의 값을 강남으로 변경되게 설정
    }
    else if (value === "gangdong") {
        seoulData = { //강동
            2013: {
                'hyperlipidemia': 30,   // 고지혈증
                'dementia': 30,        // 치매
                'diabetes': 30,        // 당뇨
                'hbp': 30              // 고혈압
            },
            2014: {
                'hyperlipidemia': 30,
                'dementia': 30,
                'diabetes': 30,
                'hbp': 30
            },
            2015: {
                'hyperlipidemia': 30,
                'dementia': 30,
                'diabetes': 30,
                'hbp': 30
            },
            2016: {
                'hyperlipidemia': 30,
                'dementia': 30,
                'diabetes': 30,
                'hbp': 30
            },
            2017: {
                'hyperlipidemia': 39,
                'dementia': 18,
                'diabetes': 29,
                'hbp': 44
            },
            2018: {
                'hyperlipidemia': 43,
                'dementia': 20,
                'diabetes': 34,
                'hbp': 50
            },
            2019: {
                'hyperlipidemia': 37,
                'dementia': 13,
                'diabetes': 27,
                'hbp': 42
            },
            2020: {
                'hyperlipidemia': 44,
                'dementia': 19,
                'diabetes': 35,
                'hbp': 51
            },
            2021: {
                'hyperlipidemia': 36,
                'dementia': 12,
                'diabetes': 26,
                'hbp': 41
            },
            2022: {
                'hyperlipidemia': 45,
                'dementia': 21,
                'diabetes': 36,
                'hbp': 52
            },
            2023: {
                'hyperlipidemia': 45,
                'dementia': 21,
                'diabetes': 36,
                'hbp': 52
            }
        };
    }
    else if (value === "gangbuk") {
        seoulData = { //강동
            2013: {
                'hyperlipidemia': 10,   // 고지혈증
                'dementia': 10,        // 치매
                'diabetes': 10,        // 당뇨
                'hbp': 10              // 고혈압
            },
            2014: {
                'hyperlipidemia': 10,
                'dementia': 10,
                'diabetes': 10,
                'hbp': 10
            },
            2015: {
                'hyperlipidemia': 30,
                'dementia': 30,
                'diabetes': 30,
                'hbp': 30
            },
            2016: {
                'hyperlipidemia': 30,
                'dementia': 30,
                'diabetes': 30,
                'hbp': 30
            },
            2017: {
                'hyperlipidemia': 39,
                'dementia': 18,
                'diabetes': 29,
                'hbp': 44
            },
            2018: {
                'hyperlipidemia': 43,
                'dementia': 20,
                'diabetes': 34,
                'hbp': 50
            },
            2019: {
                'hyperlipidemia': 37,
                'dementia': 13,
                'diabetes': 27,
                'hbp': 42
            },
            2020: {
                'hyperlipidemia': 44,
                'dementia': 19,
                'diabetes': 35,
                'hbp': 51
            },
            2021: {
                'hyperlipidemia': 36,
                'dementia': 12,
                'diabetes': 26,
                'hbp': 41
            },
            2022: {
                'hyperlipidemia': 10,
                'dementia': 10,
                'diabetes': 10,
                'hbp': 10
            },
            2023: {
                'hyperlipidemia': 10,
                'dementia': 10,
                'diabetes': 10,
                'hbp': 10
            }
        };
    }
    else if (value === "gangseo") {

    }
    else if (value === "gwanak") {

    }
    else if (value === "gwangjin") {

    }
    else if (value === "guro") {

    }
    else if (value === "geumcheon") {

    }
    else if (value === "nowon") {

    }
    else if (value === "dobong") {

    }
    else if (value === "dongdaemun") {

    }
    else if (value === "dongjak") {

    }
    else if (value === "mapo") {

    }
    else if (value === "seodaemun") {

    }
    else if (value === "seocho") {

    }
    else if (value === "seongdong") {

    }
    else if (value === "seongbuk") {

    }
    else if (value === "songpa") {

    }
    else if (value === "yangcheon") {

    }
    else if (value === "yeongdeungpo") {

    }
    else if (value === "yongsan") {

    }
    else if (value === "eunpyeong") {

    }
    else if (value === "jongno") {

    }
    else if (value === "junggu") {

    }
    else if (value === "jungang") {

    }
}


//차트 생성
function chartSet() {
    checkRegion(document.getElementById('seoul-select').value);
    initData();
    checkBtn();
    newChart.destroy();
    initChart();
    if (hyperBtnStatus === "on") {
        newChart.destroy();
        newChart = new Chart(ctx, {
            type: 'bar',
            data: {
                labels: labelData, //x라벨
                datasets: [{ //chart에 넣을 데이터
                    label: '고지혈증',
                    data: seoulInputHyper,
                    borderWidth: 1,
                    backgroundColor: ['red'],
                    borderColor: ['red'],
                    fill: false
                }]
            },
            options: {
                plugins: {
                    title: {
                        display: true,
                        text: '고지혈증 데이터(단위 : %)',
                        font: {
                            size: 20,
                        },
                        padding: {
                            top: 10,
                            bottom: 30
                        }
                    }
                }
                ,
                scales: {
                    y: {
                        beginAtZero: true,
                        max: 60
                    }
                }
                , responsive: true, //차트 반응형 옵션
                maintainAspectRatio: true,
            }
        });
    }
    if (demenBtnStatus === "on") {
        newChart.destroy();
        newChart = new Chart(ctx, {
            type: 'bar',
            data: {
                labels: labelData, //x라벨
                datasets: [{ //chart에 넣을 데이터
                    label: '치매',
                    data: seoulInputDementia,
                    borderWidth: 1,
                    backgroundColor: ['green'],
                    borderColor: ['green']
                }]
            },
            options: {
                plugins: {
                    title: {
                        display: true,
                        text: '치매 데이터(단위 : %)',
                        font: {
                            size: 20,
                        },
                        padding: {
                            top: 10,
                            bottom: 30
                        }
                    }
                }
                ,
                scales: {
                    y: {
                        beginAtZero: true,
                        max: 60
                    }
                }
                , responsive: true, //차트 반응형 옵션
                maintainAspectRatio: true,
            }
        });
    }
    if (diaBtnStatus === "on") {
        newChart.destroy();
        newChart = new Chart(ctx, {
            type: 'bar',
            data: {
                labels: labelData, //x라벨
                datasets: [{ //chart에 넣을 데이터
                    label: '당뇨',
                    data: seoulInputDiabetes,
                    borderWidth: 1,
                    backgroundColor: ['black'],
                    borderColor: ['black']
                }]
            },
            options: {
                plugins: {
                    title: {
                        display: true,
                        text: '당뇨 데이터(단위 : %)',
                        font: {
                            size: 20,
                        },
                        padding: {
                            top: 10,
                            bottom: 30
                        }
                    }
                }
                ,
                scales: {
                    y: {
                        beginAtZero: true,
                        max: 60
                    }
                }
                , responsive: true, //차트 반응형 옵션
                maintainAspectRatio: true,
            }
        });
    }
    if (hbpBtnStatus === "on") {
        newChart.destroy();
        newChart = new Chart(ctx, {
            type: 'bar',
            data: {
                labels: labelData, //x라벨
                datasets: [{ //chart에 넣을 데이터
                    label: '고혈압',
                    data: seoulInputHbp,
                    borderWidth: 1,
                    backgroundColor: ['lightblue'],
                    borderColor: ['lightblue']
                }
                ]
            },
            options: {
                plugins: {
                    title: {
                        display: true,
                        text: '고혈압 데이터(단위 : %)',
                        font: {
                            size: 20,
                        },
                        padding: {
                            top: 10,
                            bottom: 30
                        }
                    }
                }
                ,
                scales: {
                    y: {
                        beginAtZero: true,
                        max: 60
                    }
                }
                , responsive: true, //차트 반응형 옵션
                maintainAspectRatio: true,
            }
        });
    }
}

//창 로딩시 
window.onload = function () {
    new WOW().init();
}






//차트 DOM으로 받아오기
var ctx = document.getElementById('myChart');

labelData = Object.keys(seoulData);


let chartData;

//차트 초기 생성
function initChart() {
    initData();
    seoulInputHyper = seoulHyper;
    chartData = {
        type: 'bar',
        data: {
            labels: labelData, //x라벨
            datasets: [{ //chart에 넣을 데이터
                label: '고지혈증',
                data: seoulInputHyper,
                borderWidth: 1,
                backgroundColor: ['red'],
                borderColor: ['red']
            }]
        },
        options: {
            layout: {
                padding: 10
            },
            plugins: {
                title: {
                    display: true,
                    text: '지역 데이터(단위 : %)',
                    font: {
                        size: 20,
                    },
                    padding: {
                        top: 10,
                        bottom: 30
                    }
                }
            }
            ,
            scales: {
                y: {
                    beginAtZero: true,
                    max: 60
                }
            }
            , responsive: true, //차트 반응형 옵션
            maintainAspectRatio: true,
        }
    }

    //차트 틀 생성
    newChart = new Chart(ctx, chartData);
}

//차트 데이터 입력
initChart();

//고지혈증 버튼
document.getElementById('hyper').addEventListener('click', function () {
    if (hyperBtnStatus === "off") {
        hyperBtnStatus = "on";
        demenBtnStatus = "off";
        diaBtnStatus = "off";
        hbpBtnStatus = "off";
    }
    chartSet();
})

//치매 버튼
document.getElementById('dementia').addEventListener('click', function () {
    if (demenBtnStatus === "off") {
        hyperBtnStatus = "off";
        demenBtnStatus = "on";
        diaBtnStatus = "off";
        hbpBtnStatus = "off";
    }
    chartSet();
})

//당뇨 버튼
document.getElementById('diabetes').addEventListener('click', function () {
    if (diaBtnStatus === "off") {
        hyperBtnStatus = "off";
        demenBtnStatus = "off";
        diaBtnStatus = "on";
        hbpBtnStatus = "off";
    }
    chartSet();
})

//고혈압 버튼
document.getElementById('hbp').addEventListener('click', function () {
    if (hbpBtnStatus === "off") {
        hyperBtnStatus = "off";
        demenBtnStatus = "off";
        diaBtnStatus = "off";
        hbpBtnStatus = "on";
    }
    chartSet();
})



function addYearOption() {
    removeYearOptions();
    var selectYear1 = document.getElementById("year-select-start");
    var selectYear2 = document.getElementById("year-select-end");
    for (var year = parseInt(selectYear1.value) + 1; year <= 2023; year++) {
        var option = document.createElement("option");
        option.value = year;
        option.text = year;
        selectYear2.add(option);
    }
}

function removeYearOptions() {
    var selectYear2 = document.getElementById("year-select-end");
    while (selectYear2.options.length > 1) {
        selectYear2.remove(1);
    }
}