
window.onload = function () {
    new WOW().init();
    selectValue();
    myChart.update();
};

var regionFirst;
var regionSecond;
var regionFirstValueLabel = [];
var regionSecondValueLabel = [];
var regionFirstValue;
var regionSecondValue;

//JSON 형식의 파일로 데이터를 받아올 것
var firstRegionData = [76, 77, 77, 78, 79, 79, 80, 81, 82, 81, 82, 83, 84, 84, 85];
var secondRegionData = [72, 73, 74, 74, 75, 76, 77, 78, 79, 79, 78, 80, 81, 82, 83];


/* 지역 셀렉트 박스 관련 함수*/
function selectValue() {
    regionFirst = document.getElementById("selectedRegionFirst")
    regionSecond = document.getElementById("selectedRegionSecond")
    regionFirstValueLabel = [];
    regionSecondValueLabel = [];

    regionFirstValue = regionFirst.options[regionFirst.selectedIndex].value;
    regionSecondValue = regionSecond.options[regionSecond.selectedIndex].value;

    regionCheck(regionFirstValue, regionSecondValue);

    //라벨 설정
    regionFirstValueLabel.push(String(regionFirstValue));
    chartData.datasets[0].label = regionFirstValueLabel;
    regionSecondValueLabel.push(String(regionSecondValue));
    chartData.datasets[1].label = regionSecondValueLabel;

    if (myChart) {
        myChart.destroy();
    }

    getChart();
    myChart.update();
}

//지역에 따른 데이터 설정
function regionCheck(value, value2) {
    //지역 셀렉트 첫번째
    if (value === "서울특별시") {

    }
    else if (value === "부산광역시") {
        firstRegionData = [80, 80, 80, 80, 80, 80, 80, 80, 80, 80, 80, 80, 80, 80];
        secondRegionData;
    }
    else if (value === "대구광역시") {

    }
    else if (value === "인천광역시") {

    }
    else if (value === "광주광역시") {

    }
    else if (value === "대전광역시") {

    }
    else if (value === "대전광역시") {

    }
    else if (value === "울산광역시") {

    }
    else if (value === "세종특별자치시") {

    }
    else if (value === "경기도") {

    }
    else if (value === "강원도") {

    }
    else if (value === "충청북도") {

    }
    else if (value === "충청남도") {

    }
    else if (value === "전라북도") {

    }
    else if (value === "전라남도") {

    }
    else if (value === "경상북도") {

    }
    else if (value === "경상남도") {

    }
    else if (value === "제주특별자치도") {

    }

    //지역 셀렉트 두번째
    if (value2 === "서울특별시") {

    }
    else if (value2 === "부산광역시") {
        secondRegionData = [70, 70, 70, 70, 70, 70, 70, 70, 70, 70, 70, 70, 70, 70];
    }
    else if (value2 === "대구광역시") {

    }
    else if (value2 === "인천광역시") {

    }
    else if (value2 === "광주광역시") {

    }
    else if (value2 === "대전광역시") {

    }
    else if (value2 === "대전광역시") {

    }
    else if (value2 === "울산광역시") {

    }
    else if (value2 === "세종특별자치시") {

    }
    else if (value2 === "경기도") {

    }
    else if (value2 === "강원도") {

    }
    else if (value2 === "충청북도") {

    }
    else if (value2 === "충청남도") {

    }
    else if (value2 === "전라북도") {

    }
    else if (value2 === "전라남도") {

    }
    else if (value2 === "경상북도") {

    }
    else if (value2 === "경상남도") {

    }
    else if (value2 === "제주특별자치도") {

    }
}



function getChart() {
    var selectYear1 = document.getElementById("year-select-start");
    var selectYear2 = document.getElementById("year-select-end");

    var selectYearValue1 = selectYear1.options[selectYear1.selectedIndex].value;
    var selectYearValue2 = selectYear2.options[selectYear2.selectedIndex].value;

    var selectedYears = [];
    for (var i = parseInt(selectYearValue1); i <= parseInt(selectYearValue2); i++) {
        selectedYears.push(String(i));
    }
    if (myChart) {
        myChart.destroy();
    }
    chartData.labels = selectedYears;
    chartData.datasets[0].data = firstRegionData;
    chartData.datasets[1].data = secondRegionData;
    drawChart("serviceChart", "line", chartData);
    myChart.update();
}



var chartData = {
    labels: [2010, 2011, 2012, 2013, 2014, 2015, 2016, 2017, 2018, 2019, 2020, 2021, 2022, 2023, 2024],
    datasets: [
        {
            label: "서울특별시",
            data: firstRegionData, // 실제 데이터로 대체
            backgroundColor: "#1c3664",
            borderColor: "#1c3664",
            borderWidth: 1,
        },
        {
            label: "전라남도",
            data: secondRegionData, // 실제 데이터로 대체
            backgroundColor: "red",
            borderColor: "red",
            borderWidth: 1,
        }]
};

var myChart

function drawChart(chartId, chartType, data) {
    var ctx = document.getElementById(chartId).getContext('2d');
    myChart = new Chart(ctx, {
        type: chartType,
        data: data,
        options: {
            layout: {
                padding: 30
            },
            plugins: {
                title: {
                    display: true,
                    text: '각 지역 기대수명 데이터',

                    padding: {
                        top: 10,
                    }
                }
            }
            ,
            scales: {
                y: {
                    max: 90,
                    min: 60,
                    beginAtZero: false
                }
            }
            , responsive: true, //차트 반응형 옵션
            maintainAspectRatio: true,
        },
    });
}



function addYearEndOption() {
    removeYearEndOptions();
    var selectYear1 = document.getElementById("year-select-start");
    var selectYear2 = document.getElementById("year-select-end");
    for (var year = parseInt(selectYear1.value) + 1; year <= 2026; year++) {
        var option = document.createElement("option");
        option.value = year;
        option.text = year;
        selectYear2.add(option);
    }
}

function removeYearEndOptions() {
    var selectYear2 = document.getElementById("year-select-end");
    while (selectYear2.options.length > 1) {
        selectYear2.remove(1);
    }
}