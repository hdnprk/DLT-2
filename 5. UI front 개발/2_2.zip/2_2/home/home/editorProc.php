<?php

    echo "<xmp>";
    print_r($_POST);