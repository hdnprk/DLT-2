// 데이터 설정
var xLabels = ['2018년', '2019년', '2020년', '2021년', '2022년'];
var seoulData = [43261117, 36634750, 55097331, 56007337, 58619028];
var jeonnamData = [31605286, 36292256, 54309027, 61929643, 63908759];

// 캔버스 요소 가져오기
var ctxBar = document.getElementById('barChart').getContext('2d');

// 세로 막대형 차트 생성
var barChart = new Chart(ctxBar, {
    type: 'bar',
    data: {
        labels: xLabels,
        datasets: [
            {
                label: '서울',
                data: seoulData,
                backgroundColor: 'rgba(55, 197, 180, 0.5)', // 서울 데이터 색상 및 투명도 설정
                borderWidth: 1, // 테두리 두께
                borderRadius: 10, // 막대 끝 라운드 처리
            },
            {
                label: '전라남도',
                data: jeonnamData,
                backgroundColor: 'rgba(55, 164, 197, 0.5)', // 전라남도 데이터 색상 및 투명도 설정
                borderWidth: 1, // 테두리 두께
                borderRadius: 10, // 막대 끝 라운드 처리
            }
        ]
    },
    options: {
        responsive: true,
        maintainAspectRatio: false,
        defaultFontFamily: 'GmarketSansMedium', // 모든 요소의 기본 폰트 설정
        plugins: {
            legend: {
                labels: {
                    font: {
                        family: 'GmarketSansMedium', // 서울, 전라남도 폰트 설정
                        size: 14
                    }
                }
            },
            title: {
                display: true,
                text: '서울 및 전라남도 어르신 일자리 예산',
                font: {
                    family: 'GmarketSansMedium', // 타이틀 폰트 설정
                    size: 20
                }
            }
        },
        scales: {
            x: {
                grid: {
                    display: false
                },
                title: {
                    display: true,
                },
                ticks: {
                    font: {
                        family: 'GmarketSansMedium' // x축 눈금 폰트 설정
                    }
                }
            },
            y: {
                grid: {
                    display: true
                },
                title: {
                    display: true,
                    text: '단위(천원)',
                    font: {
                        family: 'GmarketSansMedium' // y축 타이틀 폰트 설정
                    }
                },
                ticks: {
                    font: {
                        family: 'GmarketSansMedium' // y축 눈금 폰트 설정
                    },
                    padding: 30 // 패딩 값을 조정하여 '단위(천원)'과 숫자 간격 조절
                }
            }
        }
    }
});