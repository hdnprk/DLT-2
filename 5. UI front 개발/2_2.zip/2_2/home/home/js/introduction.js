// const toggleBtn = document.querySelector('.toggleBtn');
// const menu = document.querySelector('.topMenu li');
// const icon = document.querySelector('.fa-bars');


// toggleBtn.addEventListener('click', () => {
//     menu.classList.toggle('active');
//     icon.classList.toggle('active');
// })