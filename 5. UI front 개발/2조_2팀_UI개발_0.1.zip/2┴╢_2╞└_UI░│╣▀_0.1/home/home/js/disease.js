

//차트 label 업데이트 함수
function updateYearLabel(selectStart, selectEnd, newChart) {
    let labelData = [];
    if (selectStart < selectEnd) {
        for (let i = selectStart; i <= selectEnd; i++) {
            if (typeof i === "string") {
                parseInt(i);
            }
            labelData.push(i);
        }
    }
    else if (selectStart > selectEnd) {
        for (let i = selectEnd; i <= selectStart; i++) {
            if (typeof i === "string") {
                parseInt(i);
            }
            labelData.push(i);
        }
    }
    else if (selectStart === selectEnd) {
        labelData.push(selectStart);
    }
    newChart.data.labels = labelData;
    newChart.update();
}



//강남 체크박스 폼태그 확인 함수(인식 됨)
function checkGangnam(newChart, valueData) {
    while (true) {
        for (let i = 0; i < newChart.data.datasets.length; i++) {
            if (newChart.data.datasets[i].label === document.getElementById('flexCheckDefault').value) {
                newChart.data.datasets.splice(i, 1);
                newChart.update();
                return;
            } //데이터 라벨에 강남이 있는지 확인
        }
        newChart.data.datasets.push({ //chart에 넣을 데이터
            label: '강남',
            data: valueData,
            borderWidth: 1,
            backgroundColor: ['lightblue'],
            borderColor: ['lightblue']
        });
        newChart.update();
        return;
    }
}



//해남 체크박스 폼태그 확인(인식 확인 중)
function checkHaenam(newChart, valueData) {
    while (true) {
        for (let i = 0; i < newChart.data.datasets.length; i++) {
            if (newChart.data.datasets[i].label === document.getElementById('flexCheckChecked').value) {
                newChart.data.datasets.splice(i, 1);
                newChart.update();
                return;
            } //데이터 라벨에 강남이 있는지 확인
        }
        newChart.data.datasets.push({ //chart에 넣을 데이터
            label: '해남',
            data: valueData,
            borderWidth: 1,
            backgroundColor: ['red'],
            borderColor: ['red']
        });
        newChart.update();
        return;
    }
}






//창 로딩시 
window.onload = function () {
    let newChart;



    //서블릿에서 데이터를 JSON 형태로 받아옴
    //서버는 아직 미구현이기에 임시로 JSON 형식 데이터 할당
    var gangnamJsonData = '{"2013" : 79,"2014" : 81, "2015" :82, "2016": 83, "2017": 84, "2018": 84, "2019" : 85, "2020" : 86, "2021" : 85, "2022" : 85, "2023" : 86, "2024" : 86, "2025" : 87, "2026" : 87}';
    var haenamJsonData = '{"2013" : 75,"2014" : 76, "2015" :75, "2016": 76, "2017": 77, "2018": 78, "2019" : 79, "2020" : 79, "2021" : 81, "2022" : 81, "2023" : 80, "2024" : 82, "2025" : 82, "2026" : 83}';

    //json 데이터 형식으로 파싱 `
    var gangnamParsedData = JSON.parse(gangnamJsonData);
    var haenamParsedData = JSON.parse(haenamJsonData);

    //차트 DOM으로 받아오기
    let ctx = document.getElementById('myChart');

    //강남 키 값 추출
    var KeyData = Object.keys(gangnamParsedData);

    var gangnamValueData = Object.values(gangnamParsedData);
    var haenamValueData = Object.values(haenamParsedData);


    let chartData = {
        type: 'line',
        data: {
            labels: KeyData, //x라벨
            datasets: [{ //chart에 넣을 데이터
                label: '강남',
                data: gangnamValueData,
                borderWidth: 1,
                backgroundColor: ['lightblue'],
                borderColor: ['lightblue']
            },
            {
                label: '해남',
                data: haenamValueData,
                backgroundColor: ['red'],
                borderColor: ['red']
            }]
        },
        options: {
            scales: {
                y: {
                    beginAtZero: false
                }
            }
            , responsive: true, //차트 반응형 옵션
            maintainAspectRatio: true,
        }
    }

    //차트 생성
    newChart = new Chart(ctx, chartData);

    var chart = Chart.getChart(ctx);

    //셀렉트 박스 차트 적용(xlabel 범위)
    document.getElementById('submitBtn').addEventListener('click', function () {
        let selectStart = parseInt(document.getElementById('year-select-start').value);
        let selectEnd = parseInt(document.getElementById('year-select-end').value);
        updateYearLabel(selectStart, selectEnd, newChart);
    });

    //체크박스 차트 적용(데이터)
    document.getElementById('flexCheckDefault').addEventListener('click', function () {
        checkGangnam(newChart, gangnamValueData);
    });
    document.getElementById('flexCheckChecked').addEventListener('click', function () {
        checkHaenam(newChart, haenamValueData);
    });




}


// //차트 리로드 함수
// function reloadChart(ctx, newChart) {
//     chartData = newChart.data;
//     Chart.destroy(); //차트 삭제
//     var chart = Chart.getChart(ctx);

//     //차트 생성
//     newChart = new Chart(ctx, chartData);
// }

// //차트 뷰포트 리로드 이벤트 리스너
// window.addEventListener('resize', function () {
//     reloadChart(ctx, newChart);
// });