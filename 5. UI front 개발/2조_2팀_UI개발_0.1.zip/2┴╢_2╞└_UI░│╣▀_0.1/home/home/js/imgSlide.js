const slides = document.querySelector('.slider');
const slideImg = document.querySelectorAll('.slidePhoto');
let currIndex = 0;
const slideCount = slideImg.length;
