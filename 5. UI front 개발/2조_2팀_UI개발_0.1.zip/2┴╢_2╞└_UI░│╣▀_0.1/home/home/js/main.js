const toggleBtn = document.querySelector('.toggleBtn');
const menu = document.querySelector('.topMenu li');
const icon = document.querySelector('.fa-bars');


toggleBtn.addEventListener('click', () => {
    menu.classList.toggle('active');
    icon.classList.toggle('active');
})




window.onload = function(){
    const elm = document.querySelectorAll('.section');
    const elmCount = elm.length;
    elm.forEach(function(item, index){
      item.addEventListener('mousewheel', function(event){
        event.preventDefault();
        let delta = 0;

        if (!event) event = window.event;
        if (event.wheelDelta) {
            delta = event.wheelDelta / 120;
            if (window.opera) delta = -delta;
        } 
        else if (event.detail)
            delta = -event.detail / 3;

        let moveTop = window.scrollY;
        let elmSelector = elm[index];

        // wheel down : move to next section
        if (delta < 0){
          if (elmSelector !== elmCount-1){
            try{
              moveTop = window.pageYOffset + elmSelector.nextElementSibling.getBoundingClientRect().top;
            }catch(e){}
          }
        }
        // wheel up : move to previous section
        else{
          if (elmSelector !== 0){
            try{
              moveTop = window.pageYOffset + elmSelector.previousElementSibling.getBoundingClientRect().top;
            }catch(e){}
          }
        }

        const body = document.querySelector('html');
        window.scrollTo({top:moveTop, left:0, behavior:'smooth'});
      });
    });
  }

  function gangFigureChange1() {
    var imgElement1 = document.querySelector('#imgButton1 img');
    var imgElement2 = document.querySelector('#imgButton2 img');
    imgElement1.src = 'imgs/1button.png';
    imgElement2.src = 'imgs/2button.png';
  
    document.getElementById("figure1").innerText = "11%";
    document.getElementById("figure2").innerText = "22%";
    document.getElementById("figure3").innerText = "33%";
    document.getElementById("figure4").innerText = "44%";
  }
  
  function heaFigureChange1() {
    var imgElement1 = document.querySelector('#imgButton1 img');
    var imgElement2 = document.querySelector('#imgButton2 img');
    imgElement1.src = 'imgs/3button.png';
    imgElement2.src = 'imgs/4button.png';
  
    document.getElementById("figure1").innerText = "55%";
    document.getElementById("figure2").innerText = "66%";
    document.getElementById("figure3").innerText = "77%";
    document.getElementById("figure4").innerText = "88%";
  }
  
  
  function gangFigureChange2() {
    var imgElement1 = document.querySelector('#imgButton3 img');
    var imgElement2 = document.querySelector('#imgButton4 img');
    imgElement1.src = 'imgs/1button.png';
    imgElement2.src = 'imgs/2button.png';
  
    document.getElementById("figure5").innerText = "11%";
    document.getElementById("figure6").innerText = "22%";
    document.getElementById("figure7").innerText = "33%";
    document.getElementById("figure8").innerText = "44%";
  }
  
  function heaFigureChange2() {
    var imgElement1 = document.querySelector('#imgButton3 img');
    var imgElement2 = document.querySelector('#imgButton4 img');
    imgElement1.src = 'imgs/3button.png';
    imgElement2.src = 'imgs/4button.png';
  
    document.getElementById("figure5").innerText = "55%";
    document.getElementById("figure6").innerText = "66%";
    document.getElementById("figure7").innerText = "77%";
    document.getElementById("figure8").innerText = "88%";
  }



