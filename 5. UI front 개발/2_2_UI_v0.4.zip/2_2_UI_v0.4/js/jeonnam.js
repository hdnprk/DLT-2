//서블릿에서 데이터를 JSON 형태로 받아옴
//서버는 아직 미구현이기에 임시로 JSON 형식 데이터 할당
//데이터는 지역 -> 연도 -> 4대 질병(고지혈증, 치매, 당뇨, 고혈압) 순으로 저장
var newChart;
var region;
var labelData = []; //라벨 데이터

var selectYearStart = document.getElementById("year-select-start");
var selectYearEnd = document.getElementById("year-select-end");
var selectYearStartValue
var selectYearEndValue



var jeonnamSelect = document.getElementById('jeonnam-select');
var jeonnamSelectValue


//해남 고지혈증, 치매, 당뇨병, 고혈압 임시 변수
var jeonnamInputHyper;
var jeonnamInputDementia;
var jeonnamInputDiabetes;
var jeonnamInputHbp;

//고지혈증, 치매, 당뇨, 고혈압 순 데이터
var jeonnamHyper = [];
var jeonnamDementia = [];
var jeonnamDiabetes = [];
var jeonnamHbp = [];

//각 질병 버튼 상태
var hyperBtnStatus = "off";
var demenBtnStatus = "off";
var diaBtnStatus = "off";
var hbpBtnStatus = "off";


/*DB와 연결되면 유동적으로 데이터를 바꿀 수 있게 설정*/
var jeonnamData = { //전남 데이터
    2013: {
        'hyperlipidemia': 35,   // 고지혈증
        'dementia': 12,        // 치매
        'diabetes': 28,        // 당뇨
        'hbp': 40              // 고혈압
    },
    2014: {
        'hyperlipidemia': 37,
        'dementia': 14,
        'diabetes': 30,
        'hbp': 42
    },
    2015: {
        'hyperlipidemia': 33,
        'dementia': 11,
        'diabetes': 25,
        'hbp': 38
    },
    2016: {
        'hyperlipidemia': 36,
        'dementia': 15,
        'diabetes': 29,
        'hbp': 41
    },
    2017: {
        'hyperlipidemia': 34,
        'dementia': 16,
        'diabetes': 27,
        'hbp': 39
    },
    2018: {
        'hyperlipidemia': 38,
        'dementia': 18,
        'diabetes': 31,
        'hbp': 45
    },
    2019: {
        'hyperlipidemia': 32,
        'dementia': 19,
        'diabetes': 24,
        'hbp': 37
    },
    2020: {
        'hyperlipidemia': 39,
        'dementia': 17,
        'diabetes': 32,
        'hbp': 46
    },
    2021: {
        'hyperlipidemia': 31,
        'dementia': 9,
        'diabetes': 23,
        'hbp': 36
    },
    2022: {
        'hyperlipidemia': 40,
        'dementia': 19,
        'diabetes': 33,
        'hbp': 80 //해남 구분용 데이터 원래는 48
    },
    2023: {
        'hyperlipidemia': 40,
        'dementia': 19,
        'diabetes': 33,
        'hbp': 80 //해남 구분용 데이터 원래는 48
    }
};

function initData() {
    labelData = []; //라벨 데이터 초기화
    //데이터 초기화
    jeonnamHyper = [];
    jeonnamDementia = [];
    jeonnamDiabetes = [];
    jeonnamHbp = [];

    selectYearStartValue = selectYearStart.options[selectYearStart.selectedIndex].value;
    selectYearEndValue = selectYearEnd.options[selectYearEnd.selectedIndex].value;

    jeonnamSelectValue = jeonnamSelect.options[jeonnamSelect.selectedIndex].value;

    for (let i = selectYearStartValue; i <= selectYearEndValue; i++) {
        labelData.push(i);
        jeonnamHyper.push(jeonnamData[i]["hyperlipidemia"]);
        jeonnamDementia.push(jeonnamData[i]["dementia"]);
        jeonnamDiabetes.push(jeonnamData[i]["diabetes"]);
        jeonnamHbp.push(jeonnamData[i]["hbp"]);
    }
}

//질병 데이터 체크 함수
function checkBtn() {
    //고지혈증 버튼
    if (hyperBtnStatus === "on") {
        jeonnamInputHyper = jeonnamHyper;
    }

    else if (hyperBtnStatus === "off") {
        jeonnamInputHyper = [];
    }

    //치매 버튼
    if (demenBtnStatus === "on") {
        jeonnamInputDementia = jeonnamDementia;
        jeonnamInputDiabetes
    }

    else if (demenBtnStatus === "off") {
        jeonnamInputDementia = [];
        jeonnamInputDiabetes
    }

    //당뇨병 버튼
    if (diaBtnStatus === "on") {
        jeonnamInputDiabetes = jeonnamDiabetes;
    }

    else if (diaBtnStatus === "off") {
        jeonnamInputDiabetes = [];
    }

    //고혈압 버튼
    if (hbpBtnStatus === "on") {
        jeonnamInputHbp = jeonnamHbp;
    }

    else if (hbpBtnStatus === "off") {

        jeonnamInputHbp = [];
    }
}

//셀렉트 차트 적용(데이터)
document.getElementById('jeonnam-select').addEventListener('change', function () {
    chartSet();
});


//지역 체크 수정 필요
function checkRegion(value) {
    if (value === "mokpo") {
        //seoulData의 값을 목포으로 변경되게 설정
    }
    else if (value === "suncheon") {
        jeonnamData = { //전남 데이터
            2013: {
                'hyperlipidemia': 30,   // 고지혈증
                'dementia': 30,        // 치매
                'diabetes': 30,        // 당뇨
                'hbp': 30              // 고혈압
            },
            2014: {
                'hyperlipidemia': 30,
                'dementia': 30,
                'diabetes': 30,
                'hbp': 30
            },
            2015: {
                'hyperlipidemia': 30,
                'dementia': 30,
                'diabetes': 30,
                'hbp': 30
            },
            2016: {
                'hyperlipidemia': 30,
                'dementia': 30,
                'diabetes': 30,
                'hbp': 30
            },
            2017: {
                'hyperlipidemia': 39,
                'dementia': 18,
                'diabetes': 29,
                'hbp': 44
            },
            2018: {
                'hyperlipidemia': 43,
                'dementia': 20,
                'diabetes': 34,
                'hbp': 50
            },
            2019: {
                'hyperlipidemia': 37,
                'dementia': 13,
                'diabetes': 27,
                'hbp': 42
            },
            2020: {
                'hyperlipidemia': 44,
                'dementia': 19,
                'diabetes': 35,
                'hbp': 51
            },
            2021: {
                'hyperlipidemia': 36,
                'dementia': 12,
                'diabetes': 26,
                'hbp': 41
            },
            2022: {
                'hyperlipidemia': 45,
                'dementia': 21,
                'diabetes': 36,
                'hbp': 52
            },
            2023: {
                'hyperlipidemia': 45,
                'dementia': 21,
                'diabetes': 36,
                'hbp': 52
            }
        };
    }
    else if (value === "yeosu") {
        jeonnamData = { //전남 데이터
            2013: {
                'hyperlipidemia': 10,   // 고지혈증
                'dementia': 10,        // 치매
                'diabetes': 10,        // 당뇨
                'hbp': 10              // 고혈압
            },
            2014: {
                'hyperlipidemia': 10,
                'dementia': 10,
                'diabetes': 10,
                'hbp': 10
            },
            2015: {
                'hyperlipidemia': 30,
                'dementia': 30,
                'diabetes': 30,
                'hbp': 30
            },
            2016: {
                'hyperlipidemia': 30,
                'dementia': 30,
                'diabetes': 30,
                'hbp': 30
            },
            2017: {
                'hyperlipidemia': 39,
                'dementia': 18,
                'diabetes': 29,
                'hbp': 44
            },
            2018: {
                'hyperlipidemia': 43,
                'dementia': 20,
                'diabetes': 34,
                'hbp': 50
            },
            2019: {
                'hyperlipidemia': 37,
                'dementia': 13,
                'diabetes': 27,
                'hbp': 42
            },
            2020: {
                'hyperlipidemia': 44,
                'dementia': 19,
                'diabetes': 35,
                'hbp': 51
            },
            2021: {
                'hyperlipidemia': 36,
                'dementia': 12,
                'diabetes': 26,
                'hbp': 41
            },
            2022: {
                'hyperlipidemia': 10,
                'dementia': 10,
                'diabetes': 16,
                'hbp': 10
            },
            2023: {
                'hyperlipidemia': 10,
                'dementia': 10,
                'diabetes': 10,
                'hbp': 10
            }
        };
    }
    else if (value === "naju") {

    }
    else if (value === "gwangyang") {

    }
    else if (value === "haenam") {

    }
    else if (value === "jindo") {

    }
    else if (value === "sinan") {

    }
    else if (value === "yeongam") {

    }
    else if (value === "muan") {

    }
    else if (value === "hampyeong") {

    }
    else if (value === "yeonggwang") {

    }
    else if (value === "jangseong") {

    }
    else if (value === "wando") {

    }
    else if (value === "damyang") {

    }
    else if (value === "jangheung") {

    }
    else if (value === "hwasun") {

    }
    else if (value === "gurye") {

    }
    else if (value === "gokseong") {

    }
    else if (value === "gukseong") {

    }
    else if (value === "hamyang") {

    }
    else if (value === "eunpyeong") {

    }
    else if (value === "jongno") {

    }
}

//차트 생성
function chartSet() {
    checkRegion(document.getElementById('jeonnam-select').value);
    initData();
    checkBtn();
    newChart.destroy();
    initChart();
    if (hyperBtnStatus === "on") {
        newChart.destroy();
        newChart = new Chart(ctx, {
            type: 'line',
            data: {
                labels: labelData, //x라벨
                datasets: [
                    {
                        label: '고지혈증',
                        data: jeonnamInputHyper,
                        borderWidth: 1,
                        backgroundColor: ['red'],
                        borderColor: ['red']
                    }]
            },
            options: {
                plugins: {
                    title: {
                        display: true,
                        text: '고지혈증 데이터(단위 : %)',
                        font: {
                            size: 20,
                        },
                        padding: {
                            top: 10,
                            bottom: 30
                        }
                    }
                }
                ,
                scales: {
                    y: {
                        beginAtZero: true
                    }
                }
                , responsive: true, //차트 반응형 옵션
                maintainAspectRatio: true,
            }
        });
    }
    if (demenBtnStatus === "on") {
        newChart.destroy();
        newChart = new Chart(ctx, {
            type: 'line',
            data: {
                labels: labelData, //x라벨
                datasets: [
                    {
                        label: '치매',
                        data: jeonnamInputDementia,
                        borderWidth: jeonnamInputDiabetes,
                        backgroundColor: ['yellow'],
                        borderColor: ['yellow']
                    }]
            },
            options: {
                plugins: {
                    title: {
                        display: true,
                        text: '치매 데이터(단위 : %)',
                        font: {
                            size: 20,
                        },
                        padding: {
                            top: 10,
                            bottom: 30
                        }
                    }
                }
                ,
                scales: {
                    y: {
                        beginAtZero: true
                    }
                }
                , responsive: true, //차트 반응형 옵션
                maintainAspectRatio: true,
            }
        });
    }
    if (diaBtnStatus === "on") {
        newChart.destroy();
        newChart = new Chart(ctx, {
            type: 'line',
            data: {
                labels: labelData, //x라벨
                datasets: [
                    {
                        label: '당뇨',
                        data: jeonnamInputDiabetes,
                        borderWidth: 1,
                        backgroundColor: ['black'],
                        borderColor: ['black']
                    }]
            },
            options: {
                plugins: {
                    title: {
                        display: true,
                        text: '당뇨 데이터(단위 : %)',
                        font: {
                            size: 20,
                        },
                        padding: {
                            top: 10,
                            bottom: 30
                        }
                    }
                }
                ,
                scales: {
                    y: {
                        beginAtZero: true
                    }
                }
                , responsive: true, //차트 반응형 옵션
                maintainAspectRatio: true,
            }
        });
    }
    if (hbpBtnStatus === "on") {
        newChart.destroy();
        newChart = new Chart(ctx, {
            type: 'line',
            data: {
                labels: labelData, //x라벨
                datasets: [
                    {
                        label: '고혈압',
                        data: jeonnamInputHbp,
                        borderWidth: 1,
                        backgroundColor: ['lightblue'],
                        borderColor: ['lightblue']
                    }]
            },
            options: {
                plugins: {
                    title: {
                        display: true,
                        text: '고혈압 데이터(단위 : %)',
                        font: {
                            size: 20,
                        },
                        padding: {
                            top: 10,
                            bottom: 30
                        }
                    }
                }
                ,
                scales: {
                    y: {
                        beginAtZero: true
                    }
                }
                , responsive: true, //차트 반응형 옵션
                maintainAspectRatio: true,
            }
        });
    }
}

//창 로딩시 
window.onload = function () {
    new WOW().init();
}

//차트 DOM으로 받아오기
var ctx = document.getElementById('myChart');

labelData = Object.keys(jeonnamData);

//차트 데이터
let chartData;

//차트 초기 생성
function initChart() {
    initData();
    chartData = {
        type: 'line',
        data: {
            labels: labelData, //x라벨
            datasets: [{ //chart에 넣을 데이터
                label: '고지혈증',
                borderWidth: 1,
                backgroundColor: ['red'],
                borderColor: ['red']
            },
            {
                label: '치매',
                borderWidth: 1,
                backgroundColor: ['yellow'],
                borderColor: ['yellow']
            },
            {
                label: '당뇨    ',
                borderWidth: 1,
                backgroundColor: ['black'],
                borderColor: ['black']
            },
            {
                label: '고혈압',
                borderWidth: 1,
                backgroundColor: ['lightblue'],
                borderColor: ['lightblue']
            }]
        },
        options: {
            plugins: {
                title: {
                    display: true,
                    text: '지역 데이터(단위 : %)',
                    font: {
                        size: 20,
                    },
                    padding: {
                        top: 10,
                        bottom: 30
                    }
                }
            }
            ,
            scales: {
                y: {
                    beginAtZero: true
                }
            }
            , responsive: true, //차트 반응형 옵션
            maintainAspectRatio: true,
        }
    }

    //차트 틀 생성
    newChart = new Chart(ctx, chartData);
}

//차트 데이터 입력
initChart();


//고지혈증 버튼
document.getElementById('hyper').addEventListener('click', function () {
    if (hyperBtnStatus === "on") {
        hyperBtnStatus = "off"
        document.getElementById('dementia').disabled = false;
        document.getElementById('diabetes').disabled = false;
        document.getElementById('hbp').disabled = false;
    }
    else if (hyperBtnStatus === "off") {
        hyperBtnStatus = "on";
        document.getElementById('dementia').disabled = true;
        document.getElementById('diabetes').disabled = true;
        document.getElementById('hbp').disabled = true;

    }
    else {
        alert("지역을 선택해주세요");
    }
    chartSet();
})

//치매 버튼
document.getElementById('dementia').addEventListener('click', function () {
    if (demenBtnStatus === "on") {
        demenBtnStatus = "off"
        document.getElementById('hyper').disabled = false;
        document.getElementById('diabetes').disabled = false;
        document.getElementById('hbp').disabled = false;
    }
    else if (demenBtnStatus === "off") {
        demenBtnStatus = "on";
        document.getElementById('hyper').disabled = true;
        document.getElementById('diabetes').disabled = true;
        document.getElementById('hbp').disabled = true;
    }
    else {
        alert("지역을 선택해주세요");
    }
    chartSet();
})

//당뇨 버튼
document.getElementById('diabetes').addEventListener('click', function () {
    if (diaBtnStatus === "on") {
        diaBtnStatus = "off"
        document.getElementById('hyper').disabled = false;
        document.getElementById('dementia').disabled = false;
        document.getElementById('hbp').disabled = false;
    }
    else if (diaBtnStatus === "off") {
        diaBtnStatus = "on";
        document.getElementById('hyper').disabled = true;
        document.getElementById('dementia').disabled = true;
        document.getElementById('hbp').disabled = true;
    }
    else {
        alert("지역을 선택해주세요");
    }
    chartSet();
})

//고혈압 버튼
document.getElementById('hbp').addEventListener('click', function () {
    if (hbpBtnStatus === "on") {
        hbpBtnStatus = "off"
        document.getElementById('hyper').disabled = false;
        document.getElementById('dementia').disabled = false;
        document.getElementById('diabetes').disabled = false;
    }
    else if (hbpBtnStatus === "off") {
        hbpBtnStatus = "on";
        document.getElementById('hyper').disabled = true;
        document.getElementById('dementia').disabled = true;
        document.getElementById('diabetes').disabled = true;
    }
    else {
        alert("지역을 선택해주세요");
    }
    chartSet();
})

function addYearOption() {
    removeYearOptions();
    var selectYear1 = document.getElementById("year-select-start");
    var selectYear2 = document.getElementById("year-select-end");
    for (var year = parseInt(selectYear1.value) + 1; year <= 2023; year++) {
        var option = document.createElement("option");
        option.value = year;
        option.text = year;
        selectYear2.add(option);
    }
}

function removeYearOptions() {
    var selectYear2 = document.getElementById("year-select-end");
    while (selectYear2.options.length > 1) {
        selectYear2.remove(1);
    }
}