// 여기에 HTML 파일에서 이동한 모든 JavaScript 코드를 넣습니다.

window.onload = function () {
    var posts = [
        { id: 1, title: "강남구 범죄정보를 알려드립니다", author: "홍길동", date: "2023-11-30" },
        { id: 2, title: "강서구 범죄정보를 알려드립니다", author: "홍길순", date: "2023-11-30" },
        { id: 3, title: "서대문구 범죄정보를 알려드립니다", author: "홍길순", date: "2023-11-30" },
        { id: 4, title: "마포구 범죄정보를 알려드립니다", author: "홍길순", date: "2023-11-30" },
        { id: 5, title: "중구 범죄정보를 알려드립니다", author: "홍길순", date: "2023-11-30" },
        { id: 6, title: "종로구 범죄정보를 알려드립니다", author: "홍길순", date: "2023-12-04" },
        { id: 7, title: "용산구 범죄정보를 알려드립니다", author: "홍길순", date: "2023-12-04" },
    ];
    var tableBody = document.querySelector("#board-table tbody");
    for (var i = 0; i < posts.length; i++) {
        var row = document.createElement("tr");
        var idCell = document.createElement("th");
        idCell.textContent = posts[i].id;

        var titleCell = document.createElement("td");
        titleCell.innerHTML = '<a href ="#">' + posts[i].title + "</a>";

        var authorCell = document.createElement("td");
        authorCell.textContent = posts[i].author;

        var dateCell = document.createElement("td");
        dateCell.textContent = posts[i].date;

        row.appendChild(idCell);
        row.appendChild(titleCell);
        row.appendChild(authorCell);
        row.appendChild(dateCell);

        tableBody.appendChild(row);

    }
};



var container = document.getElementById('map');
var options = {
    center: new kakao.maps.LatLng(37.5656, 126.9780),
    level: 7
};

var map = new kakao.maps.Map(container, options);
setZoomable(false);
function setZoomable(zoomable) {
    // 마우스 휠로 지도 확대,축소 가능여부를 설정합니다
    map.setZoomable(zoomable);
}


// 팝업 창 설정
var popupWidth = 800;
var popupHeight = 600;
var popupX = (window.screen.width / 2) - (popupWidth / 2);
var popupY = (window.screen.height / 2) - (popupHeight / 2);
var popupFeatures = "status=no, height=" + popupHeight + ", width=" + popupWidth + ", left=" + popupX + ", top=" + popupY;

// 마커를 표시할 위치와 내용을 가지고 있는 객체 배열입니다 
var positions = [
    {
        title: '은평구',
        latlng: new kakao.maps.LatLng(37.60099, 126.9314)
    },
    {
        title: '마포구',
        latlng: new kakao.maps.LatLng(37.5498, 126.9175)
    },
    {
        title: '서대문구',
        latlng: new kakao.maps.LatLng(37.57906, 126.9392)
    },
    {
        title: '중구',
        latlng: new kakao.maps.LatLng(37.5636, 126.9824)
    },
    {
        title: '종로구',
        latlng: new kakao.maps.LatLng(37.5823, 126.9882)
    },
    {
        title: '용산구',
        latlng: new kakao.maps.LatLng(37.5302, 126.9757)
    },
    {
        title: '성북구',
        latlng: new kakao.maps.LatLng(37.5906, 127.0259)
    },
    {
        title: '동대문구',
        latlng: new kakao.maps.LatLng(37.5792, 127.0367)
    }
];

// Regions을 위한 챠트 데이터
// 막대 차트 데이트

var barChartData_NP = {
    labels: ['2017', '2018', '2019', '2020', '2021', '2022', '2023'],
    datasets: [{
        label: '성범죄 증감율(은평구)',
        data: [20, 30, -10, -20, 50, 55, -15],
        backgroundColor: ['red', 'orange', 'yellow', 'green', 'blue', 'indigo', 'violet'],
    }]
};

var lineChartData_MP = {
    labels: ['2017', '2018', '2019', '2020', '2021', '2022', '2023'],
    datasets: [{
        label: '성범죄 증감율(마포구)',
        data: [20, 30, -10, -20, 50, 55, -15],
        borderColor: 'rgb(75,192,192)',
        tension: 0.1
    }]
};

var barChartData_SD = {
    labels: ['2017', '2018', '2019', '2020', '2021', '2022', '2023'],
    datasets: [{
        label: '성범죄 증감율(서대문구)',
        data: [20, 30, -10, -20, 50, 55, -15],
        backgroundColor: ['red', 'orange', 'yellow', 'green', 'blue', 'indigo', 'violet'],
    }]
};

var lineChartData_JR = {
    labels: ['2017', '2018', '2019', '2020', '2021', '2022', '2023'],
    datasets: [{
        label: '성범죄 증감율(종로구)',
        data: [20, 30, -10, -20, 50, 55, -15],
        borderColor: 'rgb(75,192,192)',
        tension: 0.1
    }]
};
var barChartData_JG = {
    labels: ['2017', '2018', '2019', '2020', '2021', '2022', '2023'],
    datasets: [{
        label: '성범죄 증감율(중구)',
        data: [20, 30, -10, -20, 50, 55, -15],
        backgroundColor: ['red', 'orange', 'yellow', 'green', 'blue', 'indigo', 'violet'],
    }]
};
var barChartData_YS = {
    labels: ['2017', '2018', '2019', '2020', '2021', '2022', '2023'],
    datasets: [{
        label: '성범죄 증감율(용산구)',
        data: [20, 30, -10, -20, 50, 55, -15],
        backgroundColor: ['red', 'orange', 'yellow', 'green', 'blue', 'indigo', 'violet'],
    }]
};


for (var i = 0; i < positions.length; i++) {
    // 마커를 생성합니다
    var marker = new kakao.maps.Marker({
        map: map, // 마커를 표시할 지도
        position: positions[i].latlng, // 마커의 위치
        title: positions[i].title //각 자치구
    });

    // 마커에 click 이벤트를 등록합니다/

    if (marker.getTitle() == '은평구') {
        kakao.maps.event.addListener(marker, 'click', makeOverListener(barChartData_NP));
    }
    if (marker.getTitle() == '마포구') {
        kakao.maps.event.addListener(marker, 'click', makeOverListener_line(lineChartData_MP));
    }
    if (marker.getTitle() == '서대문구') {
        kakao.maps.event.addListener(marker, 'click', makeOverListener(barChartData_SD));
    }
    if (marker.getTitle() == '종로구') {
        kakao.maps.event.addListener(marker, 'click', makeOverListener_line(lineChartData_JR));
    }
    if (marker.getTitle() == '중구') {
        kakao.maps.event.addListener(marker, 'click', makeOverListener(barChartData_JG));
    }
    if (marker.getTitle() == '용산구') {
        kakao.maps.event.addListener(marker, 'click', makeOverListener(barChartData_YS));
    }

}

// 서버로 부터 barCharData를 받아와서 data를 localStorage에 저장하려고 하면
// 아래의 makeOverListner(data)함수를 아래와 같이 수정하면 됨

// fetch API를 사용하여 서버에 요청을 보냅니다.
// fetch('http://127.0.0.1/api/data')
//     .then(response => response.json()) // 응답을 JSON으로 변환합니다.
//     .then(data => {
//         // 데이터를 로컬 스토리지에 저장합니다.
//         localStorage.setItem('myData', JSON.stringify(data));
//     })
//     .catch(error => console.error('Error:', error));


var type1 = 'bar';
var type2 = 'pie';
var type3 = 'line';
// 새로운 페이지에 chart를 그리는 함수. 
function makeOverListener(data) {
    return function () {
        localStorage.setItem('chartData', JSON.stringify(data));
        localStorage.setItem('graphType', JSON.stringify(type1))
        window.open('chart.html', 'PopupWindow', popupFeatures);
    };
}
function makeOverListener_line(data) {
    return function () {
        localStorage.setItem('chartData', JSON.stringify(data));
        localStorage.setItem('graphType', JSON.stringify(type3))
        window.open('chart.html', 'PopupWindow', popupFeatures);
    };
}

function drawChart(chartId, chartType, data) {
    var ctx = document.getElementById(chartId).getContext('2d');
    new Chart(ctx, {
        type: chartType,
        data: data,
        options: {}
    });
}
// 여기 데이타는 고정된 Data
var barChartData_fix = {
    labels: ['강남구', '강서구', '서대문구', '은평구', '도봉구', '영등포구', '용산구'],
    datasets: [{
        label: '2023년 자치구별 범죄정보(폭력)',
        data: [20, 30, -10, -20, 50, 55, -15],
        backgroundColor: ['red', 'orange', 'yellow', 'green', 'blue', 'indigo', 'violet'],
    }]
};
var pieChartData_fix = {
    labels: ['강남구', '강서구', '서대문구', '은평구', '도봉구', '영등포구', '용산구'],
    datasets: [{
        label: '2023년 자치구별 범죄정보(폭력)',
        data: [65, 59, 80, 81, 56, 55, 40],
        backgroundColor: ['red', 'orange', 'yellow', 'green', 'blue', 'indigo', 'violet'],
    }]
};

// 차트 그리기
drawChart('myChart1', 'bar', barChartData_fix);
drawChart('myChart2', 'pie', pieChartData_fix);



